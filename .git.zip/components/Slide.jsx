import "../styles/Banner.scss";

const Slide = () => {
  return (
    <div className="banner">
      <h1>Transform your imaginative concepts into reality </h1>
    </div>
  );
};

export default Slide;
