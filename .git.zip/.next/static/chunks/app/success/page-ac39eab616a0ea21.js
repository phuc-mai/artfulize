(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[60],{3615:function(e,r,n){Promise.resolve().then(n.bind(n,1069))},1069:function(e,r,n){"use strict";n.r(r);var t=n(7437);n(9032),r.default=()=>(0,t.jsxs)("div",{className:"success",children:[(0,t.jsx)("h1",{children:"Payment Successful"}),(0,t.jsx)("p",{children:"Thank you for your purchase!"}),(0,t.jsx)("a",{href:"/",children:"CONTINUE TO SHOPPING"})]})},9032:function(){},622:function(e,r,n){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=n(2265),s=Symbol.for("react.element"),o=Symbol.for("react.fragment"),c=Object.prototype.hasOwnProperty,u=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,f={key:!0,ref:!0,__self:!0,__source:!0};function q(e,r,n){var t,o={},i=null,a=null;for(t in void 0!==n&&(i=""+n),void 0!==r.key&&(i=""+r.key),void 0!==r.ref&&(a=r.ref),r)c.call(r,t)&&!f.hasOwnProperty(t)&&(o[t]=r[t]);if(e&&e.defaultProps)for(t in r=e.defaultProps)void 0===o[t]&&(o[t]=r[t]);return{$$typeof:s,type:e,key:i,ref:a,props:o,_owner:u.current}}r.Fragment=o,r.jsx=q,r.jsxs=q},7437:function(e,r,n){"use strict";e.exports=n(622)}},function(e){e.O(0,[971,864,744],function(){return e(e.s=3615)}),_N_E=e.O()}]);