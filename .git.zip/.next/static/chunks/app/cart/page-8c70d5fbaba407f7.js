(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[565],{2091:function(e,r,n){"use strict";var l=n(6314);r.Z=void 0;var c=l(n(984)),d=n(7437),h=(0,c.default)((0,d.jsx)("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"}),"AddCircle");r.Z=h},4210:function(e,r,n){"use strict";var l=n(6314);r.Z=void 0;var c=l(n(984)),d=n(7437),h=(0,c.default)((0,d.jsx)("path",{d:"M2 12c0 5.52 4.48 10 10 10s10-4.48 10-10S17.52 2 12 2 2 6.48 2 12zm10-1h4v2h-4v3l-4-4 4-4v3z"}),"ArrowCircleLeft");r.Z=h},6446:function(e,r,n){"use strict";var l=n(6314);r.Z=void 0;var c=l(n(984)),d=n(7437),h=(0,c.default)((0,d.jsx)("path",{d:"M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"}),"Delete");r.Z=h},12:function(e,r,n){"use strict";var l=n(6314);r.Z=void 0;var c=l(n(984)),d=n(7437),h=(0,c.default)((0,d.jsx)("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11H7v-2h10v2z"}),"RemoveCircle");r.Z=h},8258:function(e,r,n){Promise.resolve().then(n.bind(n,7314))},7314:function(e,r,n){"use strict";let l,c,d;n.r(r),n.d(r,{default:function(){return page}});var h,m=n(7437);n(4027);var f=n(4425),g=n(2091),x=n(12),y=n(6446),b=n(4210),j=n(4093),_=n.n(j),w="https://js.stripe.com/v3",k=/^https:\/\/js\.stripe\.com\/v3\/?(\?.*)?$/,findScript=function(){for(var e=document.querySelectorAll('script[src^="'.concat(w,'"]')),r=0;r<e.length;r++){var n=e[r];if(k.test(n.src))return n}return null},injectScript=function(e){var r=e&&!e.advancedFraudSignals?"?advancedFraudSignals=false":"",n=document.createElement("script");n.src="".concat(w).concat(r);var l=document.head||document.body;if(!l)throw Error("Expected document.body not to be null. Stripe.js requires a <body> element.");return l.appendChild(n),n},registerWrapper=function(e,r){e&&e._registerWrapper&&e._registerWrapper({name:"stripe-js",version:"2.2.0",startTime:r})},S=null,initStripe=function(e,r,n){if(null===e)return null;var l=e.apply(void 0,r);return registerWrapper(l,n),l},C=Promise.resolve().then(function(){return null!==S?S:S=new Promise(function(e,r){if("undefined"==typeof window||"undefined"==typeof document){e(null);return}if(window.Stripe,window.Stripe){e(window.Stripe);return}try{var n=findScript();n||(n=injectScript(null)),n.addEventListener("load",function(){window.Stripe?e(window.Stripe):r(Error("Stripe.js not available"))}),n.addEventListener("error",function(){r(Error("Failed to load Stripe.js"))})}catch(e){r(e);return}})}),N=!1;C.catch(function(e){N||console.warn(e)});var loadStripe=function(){for(var e=arguments.length,r=Array(e),n=0;n<e;n++)r[n]=arguments[n];N=!0;var l=Date.now();return C.then(function(e){return initStripe(e,r,l)})},lib_getStripe=()=>(l||(l=loadStripe("pk_test_51MfqJwDgraNiyvtnBGp9agVGmdZpM3qhOfQN56n8oTPdVze2XgxeJPSpzCDyPkl4Kydr0jfV3tKdoU3Ol642AlGC00JE8my7VN")),l),E=n(2265);let Z={data:""},t=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||Z,z=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,O=/\/\*[^]*?\*\/|  +/g,A=/\n+/g,o=(e,r)=>{let n="",l="",c="";for(let d in e){let h=e[d];"@"==d[0]?"i"==d[1]?n=d+" "+h+";":l+="f"==d[1]?o(h,d):d+"{"+o(h,"k"==d[1]?"":r)+"}":"object"==typeof h?l+=o(h,r?r.replace(/([^,])+/g,e=>d.replace(/(^:.*)|([^,])+/g,r=>/&/.test(r)?r.replace(/&/g,e):e?e+" "+r:r)):d):null!=h&&(d=/^--/.test(d)?d:d.replace(/[A-Z]/g,"-$&").toLowerCase(),c+=o.p?o.p(d,h):d+":"+h+";")}return n+(r&&c?r+"{"+c+"}":c)+l},F={},s=e=>{if("object"==typeof e){let r="";for(let n in e)r+=n+s(e[n]);return r}return e},i=(e,r,n,l,c)=>{var d;let h=s(e),m=F[h]||(F[h]=(e=>{let r=0,n=11;for(;r<e.length;)n=101*n+e.charCodeAt(r++)>>>0;return"go"+n})(h));if(!F[m]){let r=h!==e?e:(e=>{let r,n,l=[{}];for(;r=z.exec(e.replace(O,""));)r[4]?l.shift():r[3]?(n=r[3].replace(A," ").trim(),l.unshift(l[0][n]=l[0][n]||{})):l[0][r[1]]=r[2].replace(A," ").trim();return l[0]})(e);F[m]=o(c?{["@keyframes "+m]:r}:r,n?"":"."+m)}let f=n&&F.g?F.g:null;return n&&(F.g=F[m]),d=F[m],f?r.data=r.data.replace(f,d):-1===r.data.indexOf(d)&&(r.data=l?d+r.data:r.data+d),m},p=(e,r,n)=>e.reduce((e,l,c)=>{let d=r[c];if(d&&d.call){let e=d(n),r=e&&e.props&&e.props.className||/^go/.test(e)&&e;d=r?"."+r:e&&"object"==typeof e?e.props?"":o(e,""):!1===e?"":e}return e+l+(null==d?"":d)},"");function u(e){let r=this||{},n=e.call?e(r.p):e;return i(n.unshift?n.raw?p(n,[].slice.call(arguments,1),r.p):n.reduce((e,n)=>Object.assign(e,n&&n.call?n(r.p):n),{}):n,t(r.target),r.g,r.o,r.k)}u.bind({g:1});let P,q,I,D=u.bind({k:1});function goober_modern_j(e,r){let n=this||{};return function(){let l=arguments;function a(c,d){let h=Object.assign({},c),m=h.className||a.className;n.p=Object.assign({theme:q&&q()},h),n.o=/ *go\d+/.test(m),h.className=u.apply(n,l)+(m?" "+m:""),r&&(h.ref=d);let f=e;return e[0]&&(f=h.as||e,delete h.as),I&&f[0]&&I(h),P(f,h)}return r?r(a):a}}var W=e=>"function"==typeof e,T=(e,r)=>W(e)?e(r):e,L=(c=0,()=>(++c).toString()),dist_b=()=>{if(void 0===d&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");d=!e||e.matches}return d},V=new Map,$=e=>{if(V.has(e))return;let r=setTimeout(()=>{V.delete(e),dist_u({type:4,toastId:e})},1e3);V.set(e,r)},J=e=>{let r=V.get(e);r&&clearTimeout(r)},v=(e,r)=>{switch(r.type){case 0:return{...e,toasts:[r.toast,...e.toasts].slice(0,20)};case 1:return r.toast.id&&J(r.toast.id),{...e,toasts:e.toasts.map(e=>e.id===r.toast.id?{...e,...r.toast}:e)};case 2:let{toast:n}=r;return e.toasts.find(e=>e.id===n.id)?v(e,{type:1,toast:n}):v(e,{type:0,toast:n});case 3:let{toastId:l}=r;return l?$(l):e.toasts.forEach(e=>{$(e.id)}),{...e,toasts:e.toasts.map(e=>e.id===l||void 0===l?{...e,visible:!1}:e)};case 4:return void 0===r.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==r.toastId)};case 5:return{...e,pausedAt:r.time};case 6:let c=r.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+c}))}}},H=[],Q={toasts:[],pausedAt:void 0},dist_u=e=>{Q=v(Q,e),H.forEach(e=>{e(Q)})},G=(e,r="blank",n)=>({createdAt:Date.now(),visible:!0,type:r,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...n,id:(null==n?void 0:n.id)||L()}),dist_h=e=>(r,n)=>{let l=G(r,e,n);return dist_u({type:2,toast:l}),l.id},dist_n=(e,r)=>dist_h("blank")(e,r);dist_n.error=dist_h("error"),dist_n.success=dist_h("success"),dist_n.loading=dist_h("loading"),dist_n.custom=dist_h("custom"),dist_n.dismiss=e=>{dist_u({type:3,toastId:e})},dist_n.remove=e=>dist_u({type:4,toastId:e}),dist_n.promise=(e,r,n)=>{let l=dist_n.loading(r.loading,{...n,...null==n?void 0:n.loading});return e.then(e=>(dist_n.success(T(r.success,e),{id:l,...n,...null==n?void 0:n.success}),e)).catch(e=>{dist_n.error(T(r.error,e),{id:l,...n,...null==n?void 0:n.error})}),e};var R=D`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,U=D`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,K=D`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,Y=goober_modern_j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${R} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${U} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${K} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,B=D`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,X=goober_modern_j("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${B} 1s linear infinite;
`,ee=D`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,et=D`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,er=goober_modern_j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${ee} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${et} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ea=goober_modern_j("div")`
  position: absolute;
`,ei=goober_modern_j("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,eo=D`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,es=goober_modern_j("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${eo} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,M=({toast:e})=>{let{icon:r,type:n,iconTheme:l}=e;return void 0!==r?"string"==typeof r?E.createElement(es,null,r):r:"blank"===n?null:E.createElement(ei,null,E.createElement(X,{...l}),"loading"!==n&&E.createElement(ea,null,"error"===n?E.createElement(Y,{...l}):E.createElement(er,{...l})))},ye=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,ge=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,en=goober_modern_j("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,el=goober_modern_j("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Ae=(e,r)=>{let n=e.includes("top")?1:-1,[l,c]=dist_b()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ye(n),ge(n)];return{animation:r?`${D(l)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${D(c)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}};E.memo(({toast:e,position:r,style:n,children:l})=>{let c=e.height?Ae(e.position||r||"top-center",e.visible):{opacity:0},d=E.createElement(M,{toast:e}),h=E.createElement(el,{...e.ariaProps},T(e.message,e));return E.createElement(en,{className:e.className,style:{...c,...n,...e.style}},"function"==typeof l?l({icon:d,message:h}):E.createElement(E.Fragment,null,d,h))}),h=E.createElement,o.p=void 0,P=h,q=void 0,I=void 0,u`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;var ec=n(2749),page=()=>{var e,r;let{data:n,update:l}=(0,ec.useSession)(),c=null==n?void 0:null===(e=n.user)||void 0===e?void 0:e.cart,d=null==n?void 0:null===(r=n.user)||void 0===r?void 0:r._id,updateCart=async e=>{let r=await fetch("/api/users/".concat(d,"/cart"),{method:"POST",body:JSON.stringify({cart:e})}),n=await r.json();l({user:{cart:n}})},increaseQty=e=>{let r=c.map(r=>(r===e&&(r.quantity+=1),r));updateCart(r)},decreaseQty=e=>{let r=c.map(r=>(r===e&&r.quantity>1&&(r.quantity-=1),r));updateCart(r)},removeFromCart=e=>{let r=c.filter(r=>r.workId!==e.workId);updateCart(r)},h=null==c?void 0:c.reduce((e,r)=>e+r.quantity*r.price,0),handleCheckout=async()=>{let e=await lib_getStripe(),r=await fetch("/api/stripe",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({cart:c,userId:d})});if(500===r.statusCode)return;let n=await r.json();dist_n.loading("Redirecting...");let l=e.redirectToCheckout({sessionId:n.id});console.log(l),l.error&&(console.log(l.error),dist_n.error(l.error.message))};return(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(f.Z,{}),(0,m.jsx)("div",{className:"cart",children:(0,m.jsxs)("div",{className:"details",children:[(0,m.jsxs)("div",{className:"top",children:[(0,m.jsx)("h1",{children:"Your Cart"}),(0,m.jsxs)("h2",{children:["Subtotal: ",(0,m.jsxs)("span",{children:["$",null==h?void 0:h.toFixed(2)]})]})]}),(null==c?void 0:c.length)>0&&(0,m.jsxs)("div",{className:"all-items",children:[null==c?void 0:c.map((e,r)=>(0,m.jsxs)("div",{className:"item",children:[(0,m.jsxs)("div",{className:"item_info",children:[(0,m.jsx)("img",{src:e.image,alt:""}),(0,m.jsxs)("div",{className:"text",children:[(0,m.jsx)("h3",{children:e.title}),(0,m.jsxs)("p",{children:["Category: ",e.category]}),(0,m.jsxs)("p",{children:["Seller: ",e.creator.username]})]})]}),(0,m.jsxs)("div",{className:"quantity",children:[(0,m.jsx)(g.Z,{onClick:()=>increaseQty(e),sx:{fontSize:"18px",color:_().darkgrey,cursor:"pointer"}}),(0,m.jsx)("h3",{children:e.quantity}),(0,m.jsx)(x.Z,{onClick:()=>decreaseQty(e),sx:{fontSize:"18px",color:_().darkgrey,cursor:"pointer"}})]}),(0,m.jsxs)("div",{className:"price",children:[(0,m.jsx)("h2",{children:e.quantity*e.price}),(0,m.jsxs)("p",{children:["$",e.price," / each"]})]}),(0,m.jsx)("div",{className:"remove",children:(0,m.jsx)(y.Z,{onClick:()=>removeFromCart(e),sx:{cursor:"pointer"}})})]},r)),(0,m.jsxs)("div",{className:"bottom",children:[(0,m.jsxs)("a",{href:"/",children:[(0,m.jsx)(b.Z,{})," Continue shopping"]}),(0,m.jsx)("button",{onClick:()=>handleCheckout(),children:"CHECK OUT NOW"})]})]})]})})]})}},4425:function(e,r,n){"use strict";var l=n(7437),c=n(5590),d=n(9599),h=n(8991),m=n(2513),f=n(3289),g=n(1396),x=n.n(g),y=n(2265),b=n(2749);n(809);var j=n(4093),_=n.n(j),w=n(4033);r.Z=()=>{let{data:e}=(0,b.useSession)(),r=null==e?void 0:e.user,[n,g]=(0,y.useState)(""),j=(0,w.useRouter)(),handleLogout=async()=>{(0,b.signOut)({callbackUrl:"/login"})},searchWork=async()=>{""===n?j.push("/search/all"):j.push("/search/".concat(n))},[k,S]=(0,y.useState)(!1);return(0,l.jsxs)("div",{className:"navbar",children:[(0,l.jsx)("a",{href:"/",children:(0,l.jsx)("img",{src:"/assets/logo.png",alt:"logo"})}),(0,l.jsx)("div",{className:"navbar_search",children:(0,l.jsxs)("form",{onSubmit:e=>{e.preventDefault(),searchWork()},children:[(0,l.jsx)("input",{placeholder:"Search...",value:n,onChange:e=>g(e.target.value)}),(0,l.jsx)(c.Z,{children:(0,l.jsx)(h.Z,{sx:{color:_().pinkred},onClick:()=>searchWork()})})]})}),(0,l.jsxs)("div",{className:"navbar_right",children:[r&&(0,l.jsxs)("a",{href:"/cart",className:"cart",children:[(0,l.jsx)(f.Z,{sx:{color:_().darkgrey}}),"Cart ",(0,l.jsxs)("span",{children:["(",null==r?void 0:r.cart.length,")"]})]}),(0,l.jsxs)("button",{className:"navbar_right_account",onClick:()=>S(!k),children:[(0,l.jsx)(m.Z,{sx:{color:_().darkgrey}}),r?(0,l.jsx)("img",{src:r.profileImagePath,alt:"Profile",style:{objectFit:"cover",borderRadius:"50%"}}):(0,l.jsx)(d.Z,{sx:{color:_().darkgrey}})]}),k&&!r&&(0,l.jsxs)("div",{className:"navbar_right_accountmenu",children:[(0,l.jsx)(x(),{href:"/login",children:"Log In"}),(0,l.jsx)(x(),{href:"/register",children:"Sign Up"})]}),k&&r&&(0,l.jsxs)("div",{className:"navbar_right_accountmenu",children:[(0,l.jsx)(x(),{href:"/wishlist",children:"Wishlist"}),(0,l.jsx)(x(),{href:"/cart",children:"Cart"}),(0,l.jsx)(x(),{href:"/order",children:"Order"}),(0,l.jsx)(x(),{href:"/shop?id=".concat(r._id),children:"Your Shop"}),(0,l.jsx)(x(),{href:"/create-work",children:"Publish Your Work"}),(0,l.jsx)("a",{onClick:handleLogout,children:"Log Out "})]})]})]})}},4027:function(){},809:function(){},4093:function(e){e.exports={pinkred:"#f8395a",blue:"#24355a",lightgrey:"#f6f6f6",grey:"#bdb9b9",darkgrey:"#918f8e",lightblue:"#d9dfe8"}}},function(e){e.O(0,[749,30,971,864,744],function(){return e(e.s=8258)}),_N_E=e.O()}]);