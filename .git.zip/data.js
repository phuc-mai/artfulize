export const categories = [
  "All",
  "Graphics",
  "Fonts",
  "Illustrations",
  "Icons",
  "Templates",
  "Mockups",
  "3D",
  "Wallpaper",
  "Mobile",
];